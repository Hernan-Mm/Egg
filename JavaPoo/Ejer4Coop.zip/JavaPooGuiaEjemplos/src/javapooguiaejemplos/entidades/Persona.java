/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javapooguiaejemplos.entidades;



/**
 *
 * @author User
 */
public class Persona {
    
    private String nombre;
  private int edad;
    private String pais;
    private int energia;
    
    
    public Persona(){
        energia = 1000;
        
    }

    public Persona(String nombre, int edad, String pais) {
        this.nombre = nombre;
        this.edad= edad;
        this.pais = pais;
         energia = 1000;
        
        
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

   
    
    

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public String getPais() {
        return pais;
    }

   
    public int caminar(int energiaRestar){
        
       // energia = energia - energiaRestar;
        energia-=energiaRestar;
        return energia;
        
    }

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", edad=" + edad + ", pais=" + pais + ", energia=" + energia + '}';
    }

  
    

   
 
}
