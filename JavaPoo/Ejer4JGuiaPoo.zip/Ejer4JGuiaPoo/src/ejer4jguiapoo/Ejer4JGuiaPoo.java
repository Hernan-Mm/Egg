/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer4jguiapoo;

import ejer4jguiapoo.entidad.Rectangulo;

/**
 *
 * @author User
 */
public class Ejer4JGuiaPoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Rectangulo r1  = new Rectangulo();
        
        
        r1.datos();
        r1.superficie();
        r1.perimetro();
        r1.dibujo();
    }
    
}
