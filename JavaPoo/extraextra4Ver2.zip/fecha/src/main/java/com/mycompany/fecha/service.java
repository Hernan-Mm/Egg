package com.mycompany.fecha;

import java.util.Scanner;

public class service {

    int dia, mes, año, mesMax;
    Scanner sc = new Scanner(System.in);

    public entity crearFecha() {
        System.out.println("Ingresar fecha");
        System.out.println("Ingrese año");
        año = sc.nextInt();
        verificarA();
        System.out.println("Ingrese mes");
        mes = sc.nextInt();
        verificarM();
        System.out.println("Ingrese día");
        dia = sc.nextInt();
        verificarD();
        var fechaI = new entity(año, mes, dia);
        System.out.println(fechaI.toString());
        return fechaI;
    }

    private int verificarA() {
        if (año < 1900 || año > 2022) {
            System.out.println("Fecha incorrecta, año volverá al valor por defecto.");
            año = 1900;
        }
        return año;
    }

    private int verificarM() {
        if (mes < 1 || mes > 12) {
            System.out.println("Fecha incorrecta, mes volverá al valor por defecto.");
            mes = 1;
        }
        switch (mes) {
            case 2:
                if (bisiesto() == true) {
                    mesMax = 29;
                } else {
                    mesMax = 28;
                }
                break;
            case 4:
                mesMax = 30;
                break;
            case 6:
                mesMax = 30;
                break;
            case 9:
                mesMax = 30;
                break;
            case 11:
                mesMax = 30;
                break;
            default:
                mesMax = 31;
                break;
        }
        return mesMax;
    }

    private int verificarD() {
        if (dia > mesMax || dia < 1) {
            System.out.println("Fecha incorrecta, dia volverá al valor por defecto.");
            dia = 1;
        }

        return dia;
    }

    public entity diaAnt() {
        entity dA = new entity(año, mes, dia);
        if (dA.getDay() > 1) {
            dA.setDay(dA.getDay() - 1);
        } else if (dA.getMonth() > 1) {
            dA.setMonth(dA.getMonth() - 1);
            dA.setDay(verificarM() - 1);
        } else {
            dA.setYear(dA.getYear()-1);
            dA.setMonth(12);
            dA.setDay(31);
        }
        return dA;
    }

    public entity diaPos() {
        entity dP = new entity(año, mes, dia);
        dP.setDay(dP.getDay()+1);
        if (dP.getDay() == mesMax) {
            dP.setDay(1);
            dP.setMonth(dP.getMonth()+1);
        }
        if (dP.getMonth() > 12) {
            dP.setMonth(1);
            dP.setYear(dP.getYear()+1);
        }
        return dP;
    }

    public boolean bisiesto() {
        boolean bis = false;
        if (año % 4 == 0 && año % 400 != 0) {
            bis = true;
        }
        return bis;
    }

}
