/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer3guiacolect;

import ejer3guiacolect.Entidad.Alumnos;
import ejer3guiacolect.Servicio.Service;

/**
 *
 * @author User
 */
public class Ejer3GuiaColect {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Service a1 = new Service();
       Alumnos r = new Alumnos();
       a1.menu();
       a1.mostrar();
       a1.promedio();
    }
    
}
