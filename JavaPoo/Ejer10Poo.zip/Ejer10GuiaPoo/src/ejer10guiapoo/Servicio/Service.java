/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer10guiapoo.Servicio;

import ejer10guiapoo.Entidad.Numeros;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Hernan
 */
public class Service {

    Scanner leer = new Scanner(System.in);
    // Numeros a1 = new Numeros();

    public void crearVector(Numeros num) {

        System.out.println("Ingresar Tamaño del vector");
        num.setLongi(leer.nextInt());
        num.dimensionar();

    }

    //Metodo parar LLenar Vect. 1 y 2
    public void llenarVectorA(Numeros a) {
        for (int i = 0; i < a.getVa().length; i++)
        {

            a.getVa()[i] = Math.round(Math.random() * 1000);
        }

    }

    public void llenarVectorB(Numeros b) {

        Arrays.fill(b.getVa(), 0.5);

    }

    public void ordenar(Numeros a) {
        Arrays.sort(a.getVa());

    }

    public void rellenar(Numeros a, Numeros b) {
        int nu;

       System.out.println("Ingresar hasta donde realizar la copia");
       nu = leer.nextInt();
        b.setVa(Arrays.copyOf(a.getVa(), (b.getVa().length)));
        for (int i = nu; i < b.getVa().length; i++)
        {
            b.getVa()[i]= 0.5;
        }

    }

    public void mostrar(Numeros a, Numeros b) {
        System.out.println("Los numeros del Vector A son:");
        for (int i = 0; i < a.getVa().length; i++)
        {
            if (i%10==0)
            {
                System.out.println(" "); 
            }
            System.out.print("["+a.getVa()[i]+"]");
        }
        System.out.println(" ");
        System.out.println("Los numeros del Vector B son:");
        for (int i = 0; i < b.getVa().length; i++)
        {
             if (i%10==0)
            {
                System.out.println(" "); 
            }
            System.out.print("["+b.getVa()[i]+"]");
            
        }
        System.out.println(" ");
    }
    
}
