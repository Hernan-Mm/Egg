package xvi.alumno;

import java.util.ArrayList;

public class entidad {
    private String name;
    private ArrayList<Integer> grades;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList getGrades() {
        return grades;
    }

    public void setGrades(ArrayList grades) {
        this.grades = grades;
    }

    public entidad(String name, ArrayList grades) {
        this.name = name;
        this.grades = grades;
    }

    public entidad() {
    }
}
