/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer14guiapoo;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Service {
    Scanner leer = new Scanner(System.in).useDelimiter("\n"); 
    //metodo ccargar
    public Movil cargarCelular(){
        Movil m1 = new Movil();
        System.out.println("Ingresar Marca");
        m1.setMarca(leer.next() );
        System.out.println("Ingresar modelo");
        m1.setModelo(leer.next() );
        System.out.println("Ingresar precio");
        m1.setPrecio(leer.nextDouble() );
        System.out.println("Ingresar Almaceniamento");
        m1.setAlmacenamiento(leer.nextInt()  );
        System.out.println("Ingresar Memoria Ram");
        m1.setMemoriaRam(leer.nextInt() );
        return m1;
        
    }
    
    public void ingresarCodigo(Movil m){
       // System.out.println("Ingresar codigo");
        for (int i = 0; i < 7; i++)
        {
            m.getCodigo()[i]=(int) (Math.random() * 10);
        }
        
    }
    
    public void mostrar(Movil m){
        for (int i = 0; i < 7; i++)
        {
        System.out.print( m.getCodigo()[i]);
            
        }
        
    }
        
        
        
        
    
    
    
}
