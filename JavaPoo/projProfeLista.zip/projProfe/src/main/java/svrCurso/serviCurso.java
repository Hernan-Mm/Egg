package svrCurso;

import entiProfe.cursoEnti;
import java.util.Scanner;

public class serviCurso {
    Scanner lee = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
  
    public cursoEnti creaCurso() {
        
        cursoEnti c1 = new cursoEnti();
        System.out.println("Ingrese Nombre del Curso");   
        c1.setNombreCurso(lee.next());
        System.out.println("Ingrese Cantidad Horas x Día");   
        c1.setCanHorasDia(lee.nextInt());
        System.out.println("Ingrese Cantidad Días x Semana");
        c1.setCanDiasxSem(lee.nextInt());
        System.out.println("Ingrese Turno 1 para Mañana o 2 para Tarde");
        c1.setTurno(lee.nextInt());
        System.out.println("Ingrese Precio x Hora");
        c1.setPrecioHora(lee.nextInt());
        return c1;       
    }
    public void calcularGananciaSemanal(cursoEnti c1) {
        int GS = c1.getCanDiasxSem() * c1.getCanHorasDia() * c1.getPrecioHora();
        c1.setGanaSemanal(GS);
    }
    
}
    

