/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer3guiacolect.Entidad;

/**
 *
 * @author User
 */
public class Alumnos {
    
    private String nombre;
    private Integer [] notas =new Integer [3]; 
    private double notaFinal;

    public Alumnos() {
    }

    public Alumnos(String nombre, double notaFinal) {
        this.nombre = nombre;
        this.notaFinal = notaFinal;
        
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer[] getNotas() {
        return notas;
    }

    public void setNotas(Integer[] notas) {
        this.notas = notas;
    }

    public double getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(double notaFinal) {
        this.notaFinal = notaFinal;
    }

    @Override
    public String toString() {
        return "Alumnos{" + "nombre=" + nombre + ", notas=" + notas + ", notaFinal=" + notaFinal + '}';
    }

   
    
    
    
    
}
