/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer12javaguiapoo;

import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Ejer12JavaGuiaPoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner leer = new Scanner(System.in); 
        Service s1 = new Service();
        Persona p1 = new Persona();
        p1= s1.cargarPersona();
        System.out.println( s1.calcularEdad(p1, LocalDate.now())); 
        System.out.println("Ingrese edad nueva");
        int edad=leer.nextInt();
        System.out.println(s1.menorQue(edad, p1, LocalDate.now())); 
        System.out.println(p1.toString());
    }
    
}
