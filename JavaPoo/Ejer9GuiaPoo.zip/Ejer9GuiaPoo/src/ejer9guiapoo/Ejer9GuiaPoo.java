/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer9guiapoo;

import ejer9guiapoo.Entidad.Matematica;
import ejer9guiapoo.ServiceMate.Servicio;

/**
 *
 * @author User
 */
public class Ejer9GuiaPoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Matematica m1 = new Matematica();
        Servicio s1= new Servicio ();
        double total=0;
        
        m1.setNum(Math.random()*10+1);
        m1.setNum1(Math.random()*10+1);
        System.out.println(m1.getNum()+" "+ m1.getNum1());
        s1.devolverMayor(m1,total);
        s1.calcularPontencia(m1);
        s1.calcularRaiz(m1);
        
    }
    
}
