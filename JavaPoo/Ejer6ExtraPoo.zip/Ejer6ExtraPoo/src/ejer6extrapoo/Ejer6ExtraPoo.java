/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer6extrapoo;

import ejer6extrapoo.Entidad.Ahorcado;
import ejer6extrapoo.Servicio.Service;

/**
 *
 * @author Hernan
 */
public class Ejer6ExtraPoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Service s1 = new Service();
       Ahorcado a = new Ahorcado();
       s1.generarPalabra(a);
    }
    
}
