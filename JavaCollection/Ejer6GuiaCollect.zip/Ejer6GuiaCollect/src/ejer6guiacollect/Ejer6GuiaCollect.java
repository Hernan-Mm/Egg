/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer6guiacollect;

import ejer6guiacollect.Servicio.Service;

/**
 *
 * @author User
 */
public class Ejer6GuiaCollect {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Service s1= new Service();
      s1.menu();
    }
    
    
}
