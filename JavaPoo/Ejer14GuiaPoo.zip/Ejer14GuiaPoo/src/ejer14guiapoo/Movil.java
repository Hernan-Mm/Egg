/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer14guiapoo;

/**
 *
 * @author User
 */
public class Movil {
    private String modelo,marca;
    private double precio;
    private int  almacenamiento;
    private int memoriaRam;
    private int[] codigo = new int [7];

    public Movil() {
    }

    public Movil(String modelo, String marca, double precio, int almacenamiento, int memoriaRam) {
        this.modelo = modelo;
        this.marca = marca;
        this.precio = precio;
        this.almacenamiento = almacenamiento;
        this.memoriaRam = memoriaRam;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getAlmacenamiento() {
        return almacenamiento;
    }

    public void setAlmacenamiento(int almacenamiento) {
        this.almacenamiento = almacenamiento;
    }

    public int getMemoriaRam() {
        return memoriaRam;
    }

    public void setMemoriaRam(int memoriaRam) {
        this.memoriaRam = memoriaRam;
    }

    public int[] getCodigo() {
        return codigo;
    }

    public void setCodigo(int[] codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        return "Movil{" + "modelo=" + modelo + ", marca=" + marca + ", precio=" + precio + ", almacenamiento=" + almacenamiento + ", memoriaRam=" + memoriaRam +  '}';
    }

  
   
    
    
}
