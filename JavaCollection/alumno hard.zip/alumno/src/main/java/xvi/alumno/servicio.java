package xvi.alumno;

import java.util.ArrayList;
import java.util.Scanner;

public class servicio {

    Scanner scan = new Scanner(System.in).useDelimiter("\n");
    ArrayList<Integer> notas = new ArrayList();
    ArrayList<entidad> alumno = new ArrayList();
    ArrayList<String> index = new ArrayList();
    String nombre;

    private entidad createEntidad() {
        System.out.println("Ingrese nombre ");
        nombre = scan.next();
        notas.clear();                              //si no vacío el arraylist, el siguiente objeto va a tener las notas del objeto anterior
        index.add(nombre);
        for (int i = 0; i < 3; i++) {
            System.out.println("Ingrese nota " + (i + 1) + " para " + nombre);
            notas.add(scan.nextInt());
        }
        return new entidad(nombre, notas);
    }

    public void fillArray() {
        int opc;
        do {
            alumno.add(createEntidad());
            System.out.println("Desea continuar? ");
            System.out.println("1= Si. 2= No.");
            opc = scan.nextInt();
        } while (opc != 2);
    }

    private int find() {
        int indice;
        System.out.println("Ingrese el nombre de la persona a buscar:");
        String aux = scan.next();
        if (index.contains(aux)) {
            indice = index.indexOf(aux);
        } else {
            indice = -1;
        }
        return indice;
    }

    public String calculateAvg() {
        int ind = find();
        double p = 0;
        
        if (ind >= 0) {
            ArrayList<Integer> aux = alumno.get(ind).getGrades();
            /*
            for (int i = (ind*3); i < (ind*3+3); i++) {     // multiplico i *3 porque no limpiaba el arraylist notas, con lo que notas añadia las notas anteriores y las actuales
                p+= aux.get(i);
            }
            */
            for (Integer integer : aux) {
                p+=integer;
            }
            
            p = p / 3;
            return "El promedio es " + p + " index = " + ind;
        } else {
            return "La entrada no existe";
        }
    }
}
