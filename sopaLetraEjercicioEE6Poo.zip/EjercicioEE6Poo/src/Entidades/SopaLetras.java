/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

/**
 *
 * @author Ivan
 */
public class SopaLetras {

    private String[][] matriz = new String[10][10];
    private String [] palabras={"arbol", "genio", "lapiz", "autos", "mouse", "micro", "lente", "movil", "termo","placa"};
    private String alfabeto = "qwertyuiopasdfghjklñzxcvbnm";

    public SopaLetras() {
    }
    

    public String[][] getMatriz() {
        return matriz;
    }

    public void setMatriz(String[][] matriz) {
        this.matriz = matriz;
    }

    public String getAlfabeto() {
        return alfabeto;
    }

    public void setAlfabeto(String alfabeto) {
        this.alfabeto = alfabeto;
    }

    public String[] getPalabras() {
        return palabras;
    }

    public void setPalabras(String[] palabras) {
        this.palabras = palabras;
    }
    

}
