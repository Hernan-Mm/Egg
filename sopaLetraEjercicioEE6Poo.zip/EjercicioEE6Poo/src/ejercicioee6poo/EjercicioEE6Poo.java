/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicioee6poo;

import Service.SopaLetrasService;

/**
 *
 * @author Ivan
 */
public class EjercicioEE6Poo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SopaLetrasService s1=new SopaLetrasService();
        s1.llenarMatriz();
    }
    
}
