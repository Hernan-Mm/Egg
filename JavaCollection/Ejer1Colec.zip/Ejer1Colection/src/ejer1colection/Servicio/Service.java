/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer1colection.Servicio;

import ejer1colection.Entidad.Mascota;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Service {
    Scanner leer = new Scanner(System.in);  
    ArrayList<String> nombreRaza = new  ArrayList();
    
     
    public String crearRaza () {
        System.out.println("Ingresar la Raza de la Mascota");
       String raza =leer.nextLine() ;  
       
       return raza;
        
    }
    public void ingresarArray (){
        int opc=0;
        do{
        
        nombreRaza.add(crearRaza());
        System.out.println("quiere ingresar otra raza 1 o presiene 2 para salir");
        opc = leer.nextInt();
        
        } while (opc!=1);
    }
    public void mostrar(){
        for(String var:nombreRaza){
            System.out.println(var);
        }
    }
}
