/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package introjava.EjerciciosTemasGuia;

/**
 *
 * @author LuiG
 */
public class ejercicio13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] vector = {2,3,4};
        String nombre [] = {"hola","amigo"};
        String [] nombres ={"maria","juan"};
        
        for (int i = 0; i< nombres.length; i++) {
            System.out.println(nombres[i]);
        }
    }
    
}
