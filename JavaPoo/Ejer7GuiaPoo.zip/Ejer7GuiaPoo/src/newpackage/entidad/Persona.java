/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package newpackage.entidad;

import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Persona {
    Scanner Sc = new Scanner(System.in).useDelimiter("\n").useLocale(Locale.ITALY);
    
    private String nombre;
    private int edad;
    private String  sexo;
    private double peso;
    private double  altura;

    public Persona() {
    }
    //Constructor

    public Persona(String nombre, int edad, String sexo, double peso, double altura) {
        this.nombre = nombre;
        this.edad = edad;
        this.sexo = sexo;
        this.peso = peso;
        this.altura = altura;
    }

  
    //getter y setter

    public Scanner getSc() {
        return Sc;
    }

    public void setSc(Scanner Sc) {
        this.Sc = Sc;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

   

    public void setAltura(double altura) {
        this.altura = altura;
    }
    public void crearPersona(){
        
        System.out.println("Ingrear Nombre");
        this.nombre=Sc.nextLine();
        System.out.println("Ingresar edad");
        this.edad=Sc.nextInt();
        System.out.println("Ingresar Altura");
        this.altura=Sc.nextDouble();
        System.out.println("Ingresar Peso");
        this.peso=Sc.nextDouble();
        System.out.println("Ingresar Sexo ");
        this.sexo = Sc.next(); 
        while (!this.sexo.equalsIgnoreCase( "h")&& !this.sexo.equalsIgnoreCase( "m")&& !this.sexo.equalsIgnoreCase( "o")){
            
        
            System.out.println("Dato invalido ingresar h m o");
            this.sexo = Sc.next();
        
        }
        
            
            
            
        
        
    }
    
    
    
}
