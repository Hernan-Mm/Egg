package com.mycompany.fecha;


public class entity {
    
    private int year, month, day;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getDay() {
        return day;
    }

    @Override
    public String toString() {
        return "date{" + "year=" + year + ", month=" + month + ", day=" + day + '}';
    }

    public void setDay(int day) {
        this.day = day;
    }

    public entity(int year, int month, int day) {
        this.year = year;
        this.month = month;
        this.day = day;
    }

    public entity() {
        day = 1;
        month = 1;
        year = 1900;
    }
    
    
}
