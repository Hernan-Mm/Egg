/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer11guiapoo;
import ejer11guiapoo.Entidad.Persona;
import ejer11guiapoo.Servicio.Service;
/**
 *
 * @author Hernan
 */
public class Ejer11GuiaPoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Service c1 = new Service();
        Persona p1 = new Persona();
        Persona p2 = new Persona();
        
       p1= c1.crearPersona();
       // System.out.println(p1.toString());
       c1.comparar();
       p2=c1.crearPersona();
        //System.out.println(p2.toString());
       c1.comparaPersona(p1, p2);
    }
    
}
