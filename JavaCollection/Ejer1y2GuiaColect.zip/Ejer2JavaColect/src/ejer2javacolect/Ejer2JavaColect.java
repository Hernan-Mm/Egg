/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer2javacolect;

import ejer2javacolect.Entidad.Servicio.ServiceRaza;

/**
 *
 * @author User
 */
public class Ejer2JavaColect {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ServiceRaza r = new ServiceRaza();
        
        r.generaRaza();
        r.mostrarRaza();
        r.eliminarRaza();
        r.mostrarRaza();
    }
    
}
