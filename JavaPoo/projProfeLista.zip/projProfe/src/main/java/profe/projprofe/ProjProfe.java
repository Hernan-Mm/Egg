package profe.projprofe;

import entiProfe.cursoEnti;
import java.util.Scanner;
import svrCurso.serviCurso;

public class ProjProfe {

    public static void main(String[] args) {
        Scanner lee = new Scanner(System.in, "ISO-8859-1").useDelimiter("\n");
        int i;
        serviCurso csv = new serviCurso();
        cursoEnti cs = csv.creaCurso();
        csv.calcularGananciaSemanal(cs);
        cursoEnti[] lisCur = new cursoEnti[5];
        
        for (i = 0; i < 5; i++) {
            int j=i+1;
            System.out.println("Ingrese Nombre de ALumno "+j);
            cs.setNombreAlumno(lee.next());
            lisCur[i] = cs;
            System.out.println("Curso= " + lisCur[i].getNombreCurso());
            System.out.println("CanHrsxDía: " + lisCur[i].getCanHorasDia());
            System.out.println("CanDíasxSem: " + lisCur[i].getCanDiasxSem());
            System.out.println("Turno: " + lisCur[i].getTurno());
            System.out.println("PrecioxHora: " + lisCur[i].getPrecioHora());
            System.out.println("Nombre ALumno: " + lisCur[i].getNombreAlumno());
            System.out.println("Ganancia SEmanal asciende a: " + lisCur[i].getGanaSemanal());
        }

    }
}
