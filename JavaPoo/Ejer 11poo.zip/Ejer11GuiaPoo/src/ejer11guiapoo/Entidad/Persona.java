/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer11guiapoo.Entidad;

import java.time.LocalDate;

/**
 *
 * @author User
 */
public class Persona {
    public  String nom;
    public String ape;
    public String sex;
    public String pais;
    public LocalDate cumple;
    public Persona() {
    }

    public Persona(String nom, String ape, String sex, String pais, LocalDate cumple) {
        this.nom = nom;
        this.ape = ape;
        this.sex = sex;
        this.pais = pais;
        this.cumple = cumple;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getApe() {
        return ape;
    }

    public void setApe(String ape) {
        this.ape = ape;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public LocalDate getCumple() {
        return cumple;
    }

    public void setCumple(LocalDate cumple) {
        this.cumple = cumple;
    }

    @Override
    public String toString() {
        return "Persona{" + "nom=" + nom + ", ape=" + ape + ", sex=" + sex + ", pais=" + pais + ", cumple=" + cumple + '}';
    }

   
    
}
