/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer10guiapoo;

import ejer10guiapoo.Entidad.Numeros;
import ejer10guiapoo.Servicio.Service;

/**
 *
 * @author Hernan
 */
public class Ejer10GuiaPoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Service v1 = new Service();
        Numeros n1 = new Numeros();
        Numeros n2 = new Numeros();
        
        v1.crearVector(n1);
        v1.llenarVectorA(n1);
        
         v1.crearVector(n2);
         v1.llenarVectorB(n2);
        
        v1.ordenar(n1);
        v1.rellenar(n1,n2);
        v1.mostrar(n1, n2);
        
        
    }
    
}
