/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer9guiapoo.Entidad;

/**
 *
 * @author User
 */
public class Matematica {
  private   double num;
  private   double num1;

    public Matematica() {
    }

    public Matematica(double num, double num1) {
        this.num = num;
        this.num1 = num1;
    }

    public double getNum() {
        return num;
    }

    public void setNum(double num) {
        this.num = num;
    }

    public double getNum1() {
        return num1;
    }

    public void setNum1(double num1) {
        this.num1 = num1;
    }
  
  
  
}
