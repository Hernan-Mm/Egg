/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer5guiapoo.Entidad;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Banco {
    Scanner Sc = new Scanner(System.in);
    
    private int numeroCuenta;
    private long dni;
    private int saldoActual;
    

    public Banco() {
    }

    public Banco(int numeroCuenta, long dni, int saldoActual) {
        this.numeroCuenta = numeroCuenta;
        this.dni = dni;
        this.saldoActual = saldoActual;
    }

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public long getDni() {
        return dni;
    }

    public void setDni(long dni) {
        this.dni = dni;
    }

    public int getSaldoActual() {
        return saldoActual;
    }

    public void setSaldoActual(int saldoActual) {
        this.saldoActual = saldoActual;
    }
     
    public void cuenta(){
        
        System.out.println("Ingrese numero de cuenta");
        this.numeroCuenta=Sc.nextInt();
          System.out.println("Ingrese numero de DNI");
        this.dni=Sc.nextLong();
        System.out.println("Sus saldo actual es : "+saldoActual);
    }
    public void ingresar(){
        double ingresar;
        System.out.println("Ingresar un Monto");
        ingresar=Sc.nextDouble();
        this.saldoActual+=ingresar;
        System.out.println("Sus saldo actual es : "+saldoActual);
        
        
        
    }
    public void retirar(){
      double retirar;
        System.out.println("Cuanto desea retirar");
        retirar=Sc.nextDouble();
        if (retirar>saldoActual) {
            
            saldoActual=0;
            
        }else{
            saldoActual-=retirar;
        }
        System.out.println("Sus saldo actual es : "+saldoActual);
            
       
    }
    public void extRapida(){
        double retirar;
        String s=" ";
        System.out.println("Retiro rapido ");
        do
        {
            
        
        System.out.println("retirar 20%");
        retirar=Sc.nextDouble();
        if(retirar>(saldoActual*0.2)){
            System.out.println("No se puede retirar su saldo es: "+saldoActual);
            System.out.println("desea continuar presino s para salir n");
            s=Sc.next();
        }else{
            saldoActual-=retirar;
            System.out.println("desea continuar presino s para salir n");
            s=Sc.next();
        }
            
        } while (!s.equalsIgnoreCase("n"));
    }
    
    
    
    
    
}

