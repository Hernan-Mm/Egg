/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer6guiacollect.Servicio;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author User
 */


public class Service {
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    HashMap<String, Integer> listProducto = new HashMap();
   
    private void agregar (){
        int opc=1;
        do
        {
            System.out.println("Ingresar Nombre del producto"); 
        String nombre=leer.next();
        System.out.println("Ingresar Precio");
        Integer precio=leer.nextInt();
         listProducto.put(nombre,precio);
            System.out.println("Ingresar otro Producto 1 si 2 no");
            opc=leer.nextInt() ;
         
            
        
        } while (opc==1);
        System.out.println("***");
    }
    
    private void eliminarProducto()
    {
        System.out.println("Ingrese el Nombre del producto a eliminar");
        String aux=leer.next();
        if (listProducto.containsKey(aux))
        {
            listProducto.remove(aux);
        }
        else  {
            System.out.println("No se encontro");
        }
    }
    
    private void mostrar(){
        for (Map.Entry<String, Integer> entry : listProducto.entrySet())
        {
            System.out.println(entry.getKey()+":"+entry.getValue());
            
        }
    }
    private  void modificar(){
        String aux;
        System.out.println("Ingresar Producto a modificar");
        aux=leer.next();
       if(listProducto.containsKey(aux)){
           System.out.println("Ingresar nuevo precio");
           Integer aux1=leer.nextInt();
           listProducto.put(aux, aux1);
       }else{
           System.out.println("No se encontro el producto");
       }
           
        
    }
    public void menu(){
        int opc=0;
        do
        {
        System.out.println("Elija opcion");
        System.out.println("Opcion 1 Agregar Producto");
        System.out.println("Opcion 2 Eliminar Producto");
        System.out.println("Opcion 3 Modificar Producto");
        System.out.println("Opcion 4 Mostrar Productos");
        System.out.println("Opcion 5 Salir");
        opc=leer.nextInt();
            switch (opc)
            {
                case 1:
                       agregar();
                       break;
                case 2:
                       eliminarProducto();
                       break;
                 case 3:
                       modificar();
                       break;
                case 4:
                       mostrar();
                       break;
                case 5:
                       System.out.println("Esto fue todos amigos");
                       break;
                default:
                    System.out.println("Ingresa bien los datos ");
            }
            
        } while (opc!=5);
        
    }
}
