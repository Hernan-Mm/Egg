package e7_escuela.servicio;

import e7_escuela.entidades.Persona;
import java.util.Scanner;



public class PersonaServicio {

   private Scanner leer = new Scanner(System.in); 
   
   public Persona crearPersona(){
       System.out.println("Ingrese Nombre");
       String nombre=leer.nextLine();
       System.out.println("Ingrese edad");
       int edad=leer.nextInt();
       System.out.println("Ingrese sexo");
       char sexo;
       sexo=leer.next().toUpperCase().charAt(0);

       while(sexo!='O'&& sexo!='H' && sexo!= 'M' ){
           System.out.println("Intente nuevamente");
           sexo=leer.next().toUpperCase().charAt(0);
       }
          
       System.out.println("Ingrese peso");
       float peso=leer.nextFloat();
       System.out.println("Ingrese altura");
       float altura=leer.nextFloat();
                    
       
       return new Persona (nombre, edad, sexo, peso, altura);
   }
   
        public int calcularIMC (Persona s ){
            float imc;
            int resultado;
            imc=s.getPeso()/(s.getAltura()*s.getAltura());
            if (imc<20) {
                resultado=-1;
            }else if (imc>=20 && imc<=25) {
                resultado=0;
            } else {
                resultado=1;
            }
            return resultado;
        }
        
        public boolean esMayorEdad(Persona p){
            boolean adulto;
            if (p.getEdad()>17) {
                
                adulto=true;
                
            }else{
                adulto=false;
            }
            return adulto;
        }
        
}     
