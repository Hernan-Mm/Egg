/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer4jguiapoo.entidad;

import java.util.Scanner;

/**
 *
 * @author User
 */
public class Rectangulo {
    
    private int base;
    private int altura;

    public Rectangulo() {
    }

    public Rectangulo(int base, int altura) {
        this.base = base;
        this.altura = altura;
    }

    public int getBase() {
        return base;
    }

    public void setBase(int base) {
        this.base = base;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        
        this.altura = altura;
    }
    
    public void datos(){
        Scanner Sc = new Scanner(System.in);
        System.out.println("Ingresar base");
        this.base=Sc.nextInt();
        System.out.println("Ingresar Altura");
        this.altura=Sc.nextInt();
    }
    public void superficie(){
        System.out.println("La superfice es tanto: "+(base*altura) );
        
        
    }
     public void perimetro(){
         System.out.println("El perimetro es: "+(base * altura)*2);
         
     }
     
     public void dibujo(){
              for (int i = 0; i < altura ; i++) {
                  for (int j = 0; j < base; j++) {
                      System.out.print("*");
                      
                      
                  }
                  System.out.println(" ");
             
         }
     }
}

