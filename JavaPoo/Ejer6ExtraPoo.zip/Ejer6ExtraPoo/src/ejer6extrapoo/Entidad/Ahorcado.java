/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer6extrapoo.Entidad;

import java.util.Arrays;

/**
 *
 * @author Hernan
 */
public class Ahorcado {

    private String[] aPaises =
    {
        "Argentina", "Portugal", "Francia"
    };
    private String[] aObjetos =
    {
        "Computadora", "Celular", "Licuadora"
    };
    private String[] aAnimales =
    {
        "Perro", "Gato", "Puma"
    };
    private String[] palabra;
    private int intentos = 6;
    private int longi;
// Constructores

    public Ahorcado() {
    }

    public Ahorcado(String[] palabra, int longi) {
        this.palabra = palabra;
        this.longi = longi;
    }

    //Getters & Setters
    public String[] getaPaises() {
        return aPaises;
    }

    public String[] getaObjetos() {
        return aObjetos;
    }

    public String[] getaAnimales() {
        return aAnimales;
    }

    public int getIntentos() {
        return intentos;
    }

    public void setIntentos(int intentos) {
        this.intentos = intentos;
    }

    public int getLongi() {
        return longi;
    }

    public void setLongi(int longi) {
        this.longi = longi;
    }

    public String[] getPalabra() {
        return palabra;
    }

    public void setPalabra(String[] palabra) {
        this.palabra = palabra;
    }

//Metodo dimensionar palabra
    public void dimensionar() {
        palabra = new String[longi];
        Arrays.fill(palabra, "*");
    }
}
