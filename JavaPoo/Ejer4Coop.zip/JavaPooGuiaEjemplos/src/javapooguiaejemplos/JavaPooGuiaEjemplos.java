/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javapooguiaejemplos;

import java.util.Scanner;
import javapooguiaejemplos.entidades.Persona;


/**
 *
 * @author User
 */
public class JavaPooGuiaEjemplos {

    /**
     * @param args the command line arguments 
     */
    public static void main(String[] args) {
        Scanner Sc = new Scanner(System.in);
        System.out.println("Ingrese nombre, edad y pais ");
     Persona p1 = new Persona(Sc.next(), Sc.nextInt(), Sc.next());
     
     p1.caminar(250);
     
     
        System.out.println("Los datos ingresados son "+p1 );
       // System.out.println("*********");
       // System.out.println(p1);
    }
    
}
 