/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package xvi.alumno;

/**
 *
 * @author akila
 */
public class Alumno {

    public static void main(String[] args) {
    servicio serv = new servicio();
    
    serv.fillArray();
        System.out.println(serv.calculateAvg());
    }
}
