package entiProfe;

public class cursoEnti {
    private String nombreCurso;
    private int canHorasDia;
    private int canDiasxSem;
    private int turno; 
    private int precioHora;
    private int GanaSemanal;
    private String nombreAlumno;

    public cursoEnti() {
        
    }

    public cursoEnti(String nombreCurso, int canHorasDia, int canDiasxSem, int turno, int precioHora, int GanaSemanal, String nombreAlumno) {
        this.nombreCurso = nombreCurso;
        this.canHorasDia = canHorasDia;
        this.canDiasxSem = canDiasxSem;
        this.turno = turno;
        this.precioHora = precioHora;
        this.GanaSemanal = GanaSemanal;
        this.nombreAlumno = nombreAlumno;
    }

    public String getNombreCurso() {
        return nombreCurso;
    }

    public void setNombreCurso(String nombreCurso) {
        this.nombreCurso = nombreCurso;
    }

    public int getCanHorasDia() {
        return canHorasDia;
    }

    public void setCanHorasDia(int canHorasDia) {
        this.canHorasDia = canHorasDia;
    }

    public int getCanDiasxSem() {
        return canDiasxSem;
    }

    public void setCanDiasxSem(int canDiasxSem) {
        this.canDiasxSem = canDiasxSem;
    }

    public int getTurno() {
        return turno;
    }

    public void setTurno(int turno) {
        this.turno = turno;
    }

    public int getPrecioHora() {
        return precioHora;
    }

    public void setPrecioHora(int precioHora) {
        this.precioHora = precioHora;
    }

    public int getGanaSemanal() {
        return GanaSemanal;
    }

    public void setGanaSemanal(int GanaSemanal) {
        this.GanaSemanal = GanaSemanal;
    }

    public String getNombreAlumno() {
        return nombreAlumno;
    }

    public void setNombreAlumno(String nombreAlumno) {
        this.nombreAlumno = nombreAlumno;
    }


    
    
}

    


