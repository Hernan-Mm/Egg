/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colecciones_act6.servicios;

import colecciones_act6.entidades.Producto;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class ProductoService {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public void ejecucion() {

        Character op, o;
        Boolean c1, c2;
        HashMap<String, Double> productos = crearColeccion();

        do {

            op = menu();

            if (op.equals('5')) {
                do {

                    System.out.println("");
                    System.out.println("¿Estas seguro que queres salir? (s/n)");
                    System.out.print(">> ");
                    o = leer.next().charAt(0);
                    System.out.println("");

                    c1 = o.equals('s') || o.equals('S');
                    c2 = o.equals('n') || o.equals('N');

                    if (c1 || c2) {
                        break;
                    }

                } while (true);

                if (c1) {
                    break;
                }
            }

            switch (op) {

                case '1':
                    crearProducto(productos);
                    break;

                case '2':
                    mostrarColeccion(productos);
                    break;

                case '3':
                    eliminarProducto(productos);
                    break;

                case '4':
                    cambiarPrecio(productos);
                    break;
            }

        } while (true);

    }

    private Character menu() {

        Character op;

        Boolean c1;
        Boolean c2;
        Boolean c3;
        Boolean c4;
        Boolean c5;

        do {

            System.out.println("<----------------MENU---------------->");
            System.out.println("< [1] Ingresar producto              >");
            System.out.println("< [2] Mostrar lista de producto      >");
            System.out.println("< [3] Eliminar Producto              >");
            System.out.println("< [4] Cambiar Precio                 >");
            System.out.println("< [5] Salir                          >");
            System.out.println("<------------------------------------>");
            System.out.println("");
            System.out.print(">> ");
            op = leer.next().charAt(0);
            System.out.println("");

            c1 = op.equals('1');
            c2 = op.equals('2');
            c3 = op.equals('3');
            c4 = op.equals('4');
            c5 = op.equals('5');

            if (c1 || c2 || c3 || c4 || c5) {
                break;
            } else {
                System.out.println("");
                System.out.println("Error: intentelo nuevamente");
                System.out.println("");
            }

        } while (true);

        return (op);
    }

    private HashMap<String, Double> crearColeccion() {
        return new HashMap();
    }

    private void crearProducto(HashMap<String, Double> productos) {

        String nombre;
        Double precio;

        System.out.println("INGRESE LOS DATOS DEL PRODUCTO");
        System.out.println("");
        System.out.print("Nombre:>>");
        nombre = leer.next().toLowerCase();
        System.out.print("Precio:>>");
        precio = leer.nextDouble();

        ingresarProducto(productos, nombre, precio);

    }

    private void ingresarProducto(HashMap<String, Double> productos, String nombre, Double precio) {
        productos.put(nombre, precio);
    }

    private void mostrarColeccion(HashMap<String, Double> productos) {

        for (Map.Entry<String, Double> entry : productos.entrySet()) {
            System.out.println("Producto: " + entry.getKey());
            System.out.println("Precio: $" + entry.getValue());
            System.out.println("------------------------------------------");
        }

    }

    private void eliminarProducto(HashMap<String, Double> productos) {
        
        String nombre;
        
        System.out.println("Ingrese el nombre del producto a eliminar");
        System.out.print(">> ");
        nombre = leer.next().toLowerCase();
        System.out.println("");

        if (productos.containsKey(nombre)) {
            productos.remove(nombre);
        } else {
            System.out.println("El producto ingresado no se encuentra en la lista");
            System.out.println("");
        }
    }

    private void cambiarPrecio(HashMap<String, Double> productos) {

        String nombre;
        Double nuevoPrecio;

        System.out.println("Ingrese el nombre del producto a cambiar el precio");
        System.out.print(">> ");
        nombre = leer.next().toLowerCase();
        System.out.println("");

        if (productos.containsKey(nombre)) {
            System.out.println("Ingrese el nuevo precio");
            System.out.print(">> ");
            nuevoPrecio = leer.nextDouble();
            productos.put(nombre, nuevoPrecio);
        } else {
            System.out.println("El producto ingresado no se encuentra en la lista");
            System.out.println("");
        }
    }
}
