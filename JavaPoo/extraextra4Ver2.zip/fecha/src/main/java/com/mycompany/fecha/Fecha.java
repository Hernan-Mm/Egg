package com.mycompany.fecha;

public class Fecha {

    public static void main(String[] args) {
        service serv = new service();
        
        serv.crearFecha();
        System.out.println("Día anterior");
        System.out.println(serv.diaAnt());
        System.out.println("Día posterior");
        System.out.println(serv.diaPos());
        
            if(serv.bisiesto()==true){
                System.out.println("año es bisiesto.");
            }else{
                System.out.println("año no es bisiesto");
            }
    }
}
