/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
Crear una clase llamada Alumno que mantenga información sobre las notas de distintos
alumnos. La clase Alumno tendrá como atributos, su nombre y una lista de tipo Integer
con sus 3 notas.
En el servicio de Alumno deberemos tener un bucle que crea un objeto Alumno. Se pide
toda la información al usuario y ese Alumno se guarda en una lista de tipo Alumno y se le
pregunta al usuario si quiere crear otro Alumno o no.
Después de ese bucle tendremos el siguiente método en el servicio de Alumno:
Método notaFinal(): El usuario ingresa el nombre del alumno que quiere calcular su nota
final y se lo busca en la lista de Alumnos. Si está en la lista, se llama al método. Dentro
del método se usará la lista notas para calcular el promedio final de alumno. Siendo este
promedio final, devuelto por el método y mostrado en el main.
 */
package ejer3guiacolect.Servicio;

import ejer3guiacolect.Entidad.Alumnos;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Service {
    
    
 private List<Alumnos> alumnos; 
 private Scanner leer;

    public Service() {
        
        this.alumnos = new ArrayList();
        this.leer = new Scanner(System.in).useDelimiter("\n"); 
        
    }
 
 
 private  Alumnos  crearAlumno(){
     Alumnos a1 = new Alumnos();
      System.out.println("Ingresar Nombre");
      a1.setNombre(leer.next());
      System.out.println("Ingresar 3 notas");
      for (int i = 0; i < 3; i++)
     {
         a1.getNotas()[i]=leer.nextInt();
         
     }
      alumnos.add(a1);
     
      return a1;
 }
 public void menu(){
     int opc=0;
     do
     {
         crearAlumno();
         System.out.println("desea ingresar otro alumno si(1) no(2)");
         opc=leer.nextInt();
     } while (opc!=2);
     
 }
 public void mostrar(){
     for (Alumnos var : alumnos)
     {
         System.out.println(var.getNombre());
         for (int i = 0; i < 3; i++)
         {
             System.out.println(var.getNotas()[i]);
         }
        
        
     }
 }
 public void promedio (){
     double prT=0;
     for (Alumnos var : alumnos)
     {
         System.out.println(var.getNombre());  
          for (int i = 0; i < 3; i++)
     {
         prT=var.getNotas()[i]+prT;
         
     }
       var.setNotaFinal(prT/3);
       prT=0;
         System.out.println(var.getNotaFinal());
     }
     
    
     
 }
 
    
}
