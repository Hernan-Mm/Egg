/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package introjava.EjerciciosTemasGuia;

/**
 *
 * @author LuiG
 */
public class ejemplos {

    /**
     * @param args the command line arguments
     */
        public static void main(String[] args) {
            int numero1 = 6;
            int numero2 = 8;
            
            int sumar = numero1 + numero2;
            double division = numero1/numero2;
            int multiplicacion = numero1 * numero2;
            
            boolean mayor = numero1>numero2;
            
            
            
            
        }

}
    

