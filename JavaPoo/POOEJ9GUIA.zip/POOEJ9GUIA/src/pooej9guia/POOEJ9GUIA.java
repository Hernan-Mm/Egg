/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pooej9guia;

import Entidades.Matematica;

/**
 *
 * @author Ivan
 */
public class POOEJ9GUIA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Matematica op = new Matematica((Math.random() * 10),(Math.random() * 10));
        //op.setNum1(Math.random() * 10);
        //op.setNum2(Math.random() * 10);
        
        System.out.println("Número uno igual: "+ op.getNum1() + ", Número dos igual " + op.getNum2());
        System.out.println(" ");
        System.out.println("El mayor es " + Math.abs(op.devolverMayor()));
        System.out.println(" ");
        System.out.println("La potencia del mayor elevado al menor es " + op.calcularPotencia());
        System.out.println(" ");
        System.out.println("La raiz cuadrada del menor es "+ op.calcularRaiz());
        System.out.println(" ");

    }

}
