/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer14guiapoo;

/**
 *
 * @author User
 */
public class Ejer14GuiaPoo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Service s1 = new Service();
        
        Movil m1=s1.cargarCelular();
        s1.ingresarCodigo(m1);
        s1.mostrar(m1);
        System.out.println(" ");
        Movil m2 =s1.cargarCelular();
        s1.ingresarCodigo(m2);
        System.out.println(m2.toString());
        s1.mostrar(m2);
        System.out.println(m1.toString());
        
    
}
}