/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer12javaguiapoo;

import java.time.LocalDate;

/**
 *
 * @author User
 */
public class Persona {
    private String nom,ape;
    private  LocalDate edad;

    public Persona() {
    }

    public Persona(String nom, String ape, LocalDate edad) {
        this.nom = nom;
        this.ape = ape;
        this.edad = edad;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getApe() {
        return ape;
    }

    public void setApe(String ape) {
        this.ape = ape;
    }

    public LocalDate getEdad() {
        return edad;
    }

    public void setEdad(LocalDate edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Persona{" + "nom=" + nom + ", ape=" + ape + ", edad=" + edad + '}';
    }

 

    
    
    
}

