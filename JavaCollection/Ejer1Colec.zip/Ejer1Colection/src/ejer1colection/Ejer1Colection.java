/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejer1colection;

import ejer1colection.Servicio.Service;

/**
 *
 * @author User
 */
public class Ejer1Colection {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Service s1= new Service();
        s1.ingresarArray();
        s1.mostrar();
    }
    
}
