/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer11guiapoo.Servicio;

import ejer11guiapoo.Entidad.Fecha;
import ejer11guiapoo.Entidad.Persona;
import java.util.Scanner;
import java.time.LocalDate;
import java.util.Locale;
import java.time.temporal.ChronoUnit;

/**
 *
 * @author Hernan
 */
public class Service {

    Scanner leer = new Scanner(System.in).useDelimiter("\n").useLocale(Locale.ITALY);
    Fecha f1 = new Fecha();
    Persona p1 = new Persona();
    LocalDate ahora = LocalDate.now();

    public Persona crearPersona() {

        System.out.println("Ingresar Nombre");
        p1.nom = leer.next();
        System.out.println("Ingresar Apellido");
        p1.ape = leer.next();
        System.out.println("Ingresar Sexo");
        p1.sex = leer.next();
        System.out.println("Ingresar Pais de Origen");
        p1.pais = leer.next();
        cargar();
        return p1;
    }

    public void cargar() {
        System.out.println("Ingrsar Fecha de Nacimiento");
        System.out.println("Ingresar Dia");
        f1.setDia(leer.nextInt());
        System.out.println("Ingresar Mes");
        f1.setMes(leer.nextInt());
        System.out.println("Ingresar Año");
        f1.setAnio(leer.nextInt());
        p1.setCumple(LocalDate.of(f1.getAnio(), f1.getMes(), f1.getDia()));
    }
    public void comparar(){
        System.out.println( ChronoUnit.YEARS.between(p1.cumple , ahora));
        
    }
    public void comparaPersona(Persona p1 , Persona p2){
        System.out.println(ChronoUnit.YEARS.between(p1.getCumple(), p2.getCumple()));
        
        
    }
           
}
