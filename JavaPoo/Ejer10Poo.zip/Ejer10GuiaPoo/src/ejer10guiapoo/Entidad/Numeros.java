/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer10guiapoo.Entidad;

/**
 *
 * @author Hernan
 */
public class Numeros {

    private double[] va;
    private int longi;

    public Numeros() {
    }

    public Numeros(double[] va, int longi) {
        this.va = va;
        this.longi = longi;
    }

    public double[] getVa() {
        return va;
    }

    public void setVa(double[] va) {
        this.va = va;
    }

    public int getLongi() {
        return longi;
    }

    public void setLongi(int longi) {
        this.longi = longi;
    }
    
public void dimensionar(){
    va = new double [longi];
}
   
}
