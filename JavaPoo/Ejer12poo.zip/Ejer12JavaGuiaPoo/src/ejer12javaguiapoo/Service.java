/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer12javaguiapoo;

import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Service {
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    LocalDate now = LocalDate.now();
    
    public Persona cargarPersona(){
        Persona p1 = new Persona();
        System.out.println("Ingresar nombre");
        p1.setNom(leer.nextLine() );
        System.out.println("Ingresar Apellido");
        p1.setApe(leer.next());
        p1.setEdad(cumple());
        
       return p1;
    }
    
    private LocalDate cumple(){
        
        
        
        System.out.println("Ingresar dia");
        int dia = leer.nextInt();
        System.out.println("Ingresar Mes");
        int mes = leer.nextInt();
        System.out.println("Ingresar Año");
        int año= leer.nextInt();

        
        LocalDate fn = LocalDate.of(año, mes, dia);
       return fn;
    }
    
    public int calcularEdad(Persona p1, LocalDate now){
       
    return Math.abs(p1.getEdad().getYear()-now.getYear());
        
     
        
    }
    public boolean menorQue(int edad,Persona p1, LocalDate now ){
       
        
       return (calcularEdad(p1,now)> edad);
       
        
    }
    
    
}
