/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer9guiapoo.ServiceMate;

import ejer9guiapoo.Entidad.Matematica;

/**
 *
 * @author User
 */
public class Servicio {

    public void devolverMayor(Matematica mm, double total) {

        total = Math.max(mm.getNum(), mm.getNum1());
        System.out.println("El mayor es" + total);
    }

    public void calcularPontencia(Matematica mm) {
        double num1 = Math.round(mm.getNum());
        double num2 = Math.round(mm.getNum1());
        double potencia;
        if (num1 > num2)
        {
            potencia = Math.pow(num1, num2);

        } else
        {
            potencia = Math.pow(num2, num1);
        }
        System.out.println("La potencia del numero mayor es: " + potencia);
    }

    public void calcularRaiz(Matematica mm) {
        double raiz;
        double num1 = Math.abs(mm.getNum());
        double num2 = Math.abs(mm.getNum1());
        if (num1 < num2)
        {
            raiz = Math.sqrt(num1);

        } else
        {
            raiz = Math.sqrt(num2);
        }
        System.out.println("La raiz del numero menor es: " + raiz);
    }
}
