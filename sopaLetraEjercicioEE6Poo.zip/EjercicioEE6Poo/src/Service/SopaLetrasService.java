/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Entidades.SopaLetras;

/**
 *
 * @author Ivan
 */
public class SopaLetrasService {

    SopaLetras s1 = new SopaLetras();

    public void llenarMatriz() {
        int min = 0;//variable aux random
        int max = 5;

        for (int i = 0; i < 10; i++) {
            String palabra = s1.getPalabras()[i];
            int inicio = min + (int) (Math.random() * ((max - min) + 1));//random indice de inicio en columna
            int fin = palabra.length() + inicio;
            int k = 0;//variable aux substring
            for (int j = 0; j < 10; j++) {
                if (j == inicio && j < fin)   {
                    s1.getMatriz()[i][j] = palabra.substring(k, k + 1);
                    inicio++;
                    k++;
                } else {
                    int opcion = (int) (Math.random() * s1.getAlfabeto().length());
                    s1.getMatriz()[i][j] = s1.getAlfabeto().substring(opcion, opcion + 1);
                }
            }
        }
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print(s1.getMatriz()[i][j]);
                System.out.print(" ");
            }
            System.out.println(" ");
        }
        System.out.println("");

    }
}
