/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejer6extrapoo.Servicio;

import ejer6extrapoo.Entidad.Ahorcado;
import java.util.Scanner;

/**
 *
 * @author Hernan
 */
public class Service {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    //Metodo ingresar letra
    private String ingresarLetra() {

        System.out.println("Ingrese la letra ");
        return leer.next();
    }

    //Metodo para generar la palabra a buscar
    public void generarPalabra(Ahorcado a) {
        int opc;
        System.out.println("Que desea adivinar Paises=1 Objetos=2 o Animales=3");
        opc = leer.nextInt();

        switch (opc)
        {
            case 1:
                juegoPaises(a);

                break;

            case 2:
                juegoObjetos(a);

                break;
            case 3:
                juegoAnimales(a);

                break;

        }
    }

    //Metodo para buscar letra en palabra relacionadas con paises
    private void juegoPaises(Ahorcado a) {
        int num = (int) (Math.random() * 3 - 1);
        int bandera = 0;
        int c = 0;
        int in = 0;
        a.setLongi(a.getaPaises()[num].length());
        a.dimensionar();
        a.getPalabra()[0] = a.getaPaises()[num].substring(0, 1);

        System.out.println("La palabra a buscar tiene " + a.getLongi() + " letras y empieza con: ");
        for (int j = 0; j < a.getLongi(); j++)
        {
            System.out.print(a.getPalabra()[j]);
        }
        System.out.println("");
        do
        {
            System.out.println("Tienes " + a.getIntentos() + " Intentos para adivinar ");
            String letra = ingresarLetra();

            for (int i = 1; i < a.getLongi(); i++)
            {
                if (letra.equals(a.getaPaises()[num].substring(i, i + 1)))
                {
                    System.out.println("La letra esta");
                    a.getPalabra()[i] = letra;
                    c++;
                } else
                {
                    in++;

                }

            }

            for (int j = 0; j < a.getLongi(); j++)
            {
                System.out.print(a.getPalabra()[j]);
            }
            System.out.println("");
            if (in == a.getLongi() - 1)
            {
                a.setIntentos(a.getIntentos() - 1);
            }
            System.out.println(a.getIntentos());
            in = 0;
            if (c == a.getLongi() - 1 || a.getIntentos() == 0)
            {
                bandera = 1;
            }
        } while (bandera != 1);
        if (a.getIntentos() != 0)
        {
            System.out.println("Ganaste");
        }

    }

    //Metodo para buscar letra en palabra relacionadas con objetos
    private void juegoObjetos(Ahorcado a) {
        int num = (int) (Math.random() * 3 - 1);
        int bandera = 0;
        int c = 0;
        int in = 0;
        a.setLongi(a.getaObjetos()[num].length());
        a.dimensionar();
        a.getPalabra()[0] = a.getaObjetos()[num].substring(0, 1);
        System.out.println("La palabra a buscar tiene " + a.getLongi() + " letras y empieza con: ");
        for (int j = 0; j < a.getLongi(); j++)
        {
            System.out.print(a.getPalabra()[j]);
        }
        System.out.println("");

        do
        {
            System.out.println("Tienes " + a.getIntentos() + " Intentos para adivinar ");
            String letra = ingresarLetra();

            for (int i = 1; i < a.getLongi(); i++)
            {
                if (letra.equals(a.getaObjetos()[num].substring(i, i + 1)))
                {
                    System.out.println("La letra esta");
                    a.getPalabra()[i] = letra;
                    c++;
                } else
                {
                    in++;

                }

            }

            for (int j = 0; j < a.getLongi(); j++)
            {
                System.out.print(a.getPalabra()[j]);
            }
            System.out.println("");
            if (in == a.getLongi() - 1)
            {
                a.setIntentos(a.getIntentos() - 1);
            }
            System.out.println(a.getIntentos());
            in = 0;
            if (c == a.getLongi() - 1 || a.getIntentos() == 0)
            {
                bandera = 1;
            }
        } while (bandera != 1);
        if (a.getIntentos() != 0)
        {
            System.out.println("Ganaste");
        }

    }
    //Metodo para buscar letra en palabra relacionadas con animales

    private void juegoAnimales(Ahorcado a) {
        int num = (int) (Math.random() * 3 - 1);
        int bandera = 0;
        int c = 0;
        int in = 0;
        a.setLongi(a.getaAnimales()[num].length());
        a.dimensionar();
        a.getPalabra()[0] = a.getaAnimales()[num].substring(0, 1);
        System.out.println("La palabra a buscar tiene " + a.getLongi() + " letras y empieza con: ");
        for (int j = 0; j < a.getLongi(); j++)
        {
            System.out.print(a.getPalabra()[j]);
        }
        System.out.println("");

        do
        {
            System.out.println("Tienes " + a.getIntentos() + " Intentos para adivinar ");
            String letra = ingresarLetra();

            for (int i = 1; i < a.getLongi(); i++)
            {
                if (letra.equals(a.getaAnimales()[num].substring(i, i + 1)))
                {
                    System.out.println("La letra esta");
                    a.getPalabra()[i] = letra;
                    c++;
                } else
                {
                    in++;

                }

            }

            for (int j = 0; j < a.getLongi(); j++)
            {
                System.out.print(a.getPalabra()[j]);
            }
            System.out.println("");
            if (in == a.getLongi() - 1)
            {
                a.setIntentos(a.getIntentos() - 1);
            }
            System.out.println(a.getIntentos());
            in = 0;
            if (c == a.getLongi() - 1 || a.getIntentos() == 0)
            {
                bandera = 1;
            }
        } while (bandera != 1);
        if (a.getIntentos() != 0)
        {
            System.out.println("Ganaste");
        }

    }

}
